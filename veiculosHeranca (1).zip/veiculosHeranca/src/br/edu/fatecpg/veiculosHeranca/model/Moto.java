package br.edu.fatecpg.veiculosHeranca.model;

public class Moto extends Veiculo {
		
		public int num_passageiros;
		public String tipo;
		
		public Moto(String mod, String mrc, int ano, String cor, int num_pass, String tipo) {
			super(mod, mrc,ano,cor);
			this.num_passageiros = num_pass;
			this.tipo = tipo;
		}
		
		public void andar() {
			System.out.println("andando...");
		}
		
		public void cair() {
			System.out.println("cair!");
		}
}
