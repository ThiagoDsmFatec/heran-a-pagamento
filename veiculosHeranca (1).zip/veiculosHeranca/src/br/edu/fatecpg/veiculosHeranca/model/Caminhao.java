package br.edu.fatecpg.veiculosHeranca.model;

public class Caminhao extends Veiculo {
		
		public int num_passageiros;
		public String tipo;
		
		public Caminhao (String mod, String mrc, int ano, String cor, int num_pass, String tipo) {
			super(mod, mrc,ano,cor);
			this.num_passageiros = num_pass;
			this.tipo = tipo;
		}
		
		public void carregar() {
			System.out.println("carregando...");
		}
		
		public void transportar() {
			System.out.println("transportando");
		}
}
