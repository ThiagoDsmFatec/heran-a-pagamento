package br.edu.fatecpg.veiculosHeranca.model;

public class Veiculo {
public String modelo;
public String marca;
public int ano;
public String cor;

public Veiculo  ( String mod, String mrc, int ano, String cor) {

this.modelo= mod;
this.marca = mrc;
this.ano = ano;
this.cor = cor;
}

 public void ligar() {
	 System.out.println("ligando...");
	 System.out.println("ligado");}
	 
 public void desligar() {
	 System.out.println("desligando");
	 System.out.println("desligado");}
 }