package br.edu.fatecpg.veiculosHeranca.view;

import br.edu.fatecpg.veiculosHeranca.model.Caminhao;
import br.edu.fatecpg.veiculosHeranca.model.Carro;
import br.edu.fatecpg.veiculosHeranca.model.Moto;
import br.edu.fatecpg.veiculosHeranca.model.Veiculo;

public class Main {

	public static void main(String[] args) {
		Carro carro = new Carro ("Renaut","Logan", 2015, "Prata", 5,"Sedan") ;
		Moto moto = new Moto ("Honda","CBX500",2023,"Preto",2, "passeio");
		Caminhao caminhao = new Caminhao ("Mercedes","1620", 2020, "Branco",4,"utilitario") ;
		
		carro.ligar();
		carro.desligar();
		
	carro.ligarAr();
	carro.acelerar();
	
    moto.andar();
    moto.cair();
    
    caminhao.transportar();
    caminhao.carregar();
	}

}
