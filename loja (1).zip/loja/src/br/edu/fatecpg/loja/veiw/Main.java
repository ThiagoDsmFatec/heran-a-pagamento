package br.edu.fatecpg.loja.veiw;

import br.edu.fatecpg.loja.model.Faxineiro;
import br.edu.fatecpg.loja.model.Gerente;

public class Main {
	public static void main(String[] args) {
		Faxineiro faxi = new Faxineiro();
		faxi.solicitarMaterial();
		
		Gerente ger = new Gerente();
		ger.baterPonto();
		ger.realizarVenda();
		ger.fecharCaixa();
		
		
		
	}

}
