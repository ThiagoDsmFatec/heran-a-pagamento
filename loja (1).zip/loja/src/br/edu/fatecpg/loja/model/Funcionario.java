package br.edu.fatecpg.loja.model;

public interface Funcionario {
	public void baterPonto();
	

}
