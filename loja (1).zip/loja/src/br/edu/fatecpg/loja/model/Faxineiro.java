package br.edu.fatecpg.loja.model;

public class Faxineiro implements Funcionario{

	@Override
	public void baterPonto() {
			System.out.println("ponto registrado");
		
	}
	
	public void solicitarMaterial() {
		System.out.println("solicitado");}
	
	

}
