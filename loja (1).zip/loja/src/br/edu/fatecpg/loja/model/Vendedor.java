package br.edu.fatecpg.loja.model;

public abstract class Vendedor implements Funcionario{

	@Override
	public void baterPonto() {
		System.out.println("ponto registrado");
		
	}
	public void realizarVenda() {
		System.out.println("vendido");}



}
