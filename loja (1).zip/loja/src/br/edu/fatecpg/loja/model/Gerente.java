package br.edu.fatecpg.loja.model;

public class Gerente extends Vendedor implements Funcionario{
	
	public void fecharCaixa() {
		System.out.println("caixa fechado!");}


}
