public interface OperacaoMatematica {


    
    double soma(double a, double b);
    double subtracao(double a, double b);
    double multiplicacao(double a, double b);
    double divisao(double a, double b);
}
